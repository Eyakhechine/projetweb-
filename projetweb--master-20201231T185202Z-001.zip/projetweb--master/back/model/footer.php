<footer class="container-fluid text-center">
  <p>URBAND SPORT SHOP</p>
</footer>

</body>
</html>