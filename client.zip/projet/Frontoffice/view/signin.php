<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title> URBAND SPORT SHOP</title>
  
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">WELCOME</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#CATEGORIES">CATEGORIES</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="sign.php">SIGN UP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#SHOPPING CART">SHOPPING CART</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center">
      <h1>URBAND SPORT SHOP</h1>
      <img src="got.png">
      <p class="lead">_ DON't DELAY SALE IS TODAY _</p>

      <img src="logo.png">
   

    </div>
  </header>


  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
            <h2 class="text-center">Create Your Account</h2>
            <form class="text-left clearfix" method="post" action="AjouterUser.php">
              <div class="form-group">
                <input type="text" class="form-control" name="nom" placeholder="First Name">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="prenom" placeholder="Last Name">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="adresse" placeholder="Adresse">
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Email">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" name="mdp" placeholder="Password">
              </div>
                <div class="form-group">
                <input type="text" class="form-control" name="tel" placeholder="numero">
              </div>
                <div class="form-group">
                <input type="date" class="form-control" name="date" placeholder="Votre date de naissance">
              </div>
                <div class="form-group">
                <input type="file" class="form-control" name="photo" placeholder="Ajouter une photo">
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-main text-center">Sign In</button>
              </div>
            </form>
            <p class="mt-20">Already hava an account ?<a href="sign.php"> Login</a></p>
            <p><a href="forget-password.html"> Forgot your password?</a></p>
          </div>
        </div>
      </div>
    </div>
  </section>



  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white"> GO CHECK CATEGORIES AND ENJOY SCROLLING</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
